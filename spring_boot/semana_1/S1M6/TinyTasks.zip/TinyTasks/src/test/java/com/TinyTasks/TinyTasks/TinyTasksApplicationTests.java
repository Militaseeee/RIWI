package com.TinyTasks.TinyTasks;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TinyTasksApplicationTests {

	@Test
	void contextLoads() {
	}

}
