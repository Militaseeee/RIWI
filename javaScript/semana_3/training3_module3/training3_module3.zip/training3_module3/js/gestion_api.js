const newProduct = { "id": 4, "name": "Monitor", "price": 200 };

// Create a new product (POST)
fetch('http://localhost:3000/products', {
    method: 'POST',
    headers: {'Content-Type': 'application/json' },
    body: JSON.stringify(newProduct),
})
    .then(response => response.json())
    .then(data => console.log("Available products:", data))
    .catch(error => console.error("Error getting products", error));

// console.log(newProduct)

const UpdateProduct = { "name": "Laptop", "price": 1400 };

fetch('http://localhost:3000/products', {
    method: 'POST',
    headers: {'Content-Type': 'application/json' },
    body: JSON.stringify(UpdateProduct)
})
    .then(response => response.json())
    .then(data => console.log("Updated product:", data))
    .catch(error => console.error("Error gupdating product", error));

// console.log(UpdateProduct)