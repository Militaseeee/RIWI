// json-server --watch db.json

const BASE_API_URL = "http://localhost:3000/products";

const modalCrud = document.getElementById('modalCrud');
const modalTitle = document.getElementById('modalTitle');
const modalContent = document.getElementById('modalContent');
const modalForm = document.getElementById('modalForm');

let choseCrud = ""


const showProducts = async () => {
    try {
        const response = await fetch(`${BASE_API_URL}`);
        const data = await response.json();

        // Clears the current content of the modal
        modalContent.innerHTML = "";
        if (data.length === 0) {
            const msg = document.createElement("p");
            msg.textContent = "There are no products available";
            modalContent.appendChild(msg);
            return;
        }
    
        // Create table
        const table = document.createElement("table");
        table.classList.add("product-table");
    
        // Create header
        const thead = document.createElement("thead");
        const headerRow = document.createElement("tr");
    
        ["ID", "NAME", "PRICE"].forEach(text => {
            const th = document.createElement("th");
            th.textContent = text;
            headerRow.appendChild(th);
        });
    
        thead.appendChild(headerRow);
        table.appendChild(thead);
    
        // Create table body
        const tbody = document.createElement("tbody");
    
        data.forEach(product => {
            const row = document.createElement("tr");
            
            const cellId = document.createElement("td");
            cellId.textContent = product.id;
            
            const cellName = document.createElement("td");
            cellName.textContent = product.name;
            
            const cellPrice = document.createElement("td");
            cellPrice.textContent = `$${product.price}`;
            
            row.appendChild(cellId);
            row.appendChild(cellName);
            row.appendChild(cellPrice);
            
            tbody.appendChild(row);
        });
    
        table.appendChild(tbody);
        modalContent.appendChild(table);

    } catch (error) {

        console.error("Error fetching products:", error);
        const errorMsg = document.createElement("p");
        errorMsg.textContent = "Error getting products";
        errorMsg.classList.add("error-message");
        modalContent.innerHTML = "";
        modalContent.appendChild(errorMsg);
    }
};

const confirmButton = document.getElementById('confirm-button')

function selectCrud(accion) {

    choseCrud = accion;
    switch (accion) {
        case "show":
            modalTitle.textContent = "Show products";
            modalContent.innerHTML = "<p>Loading products...</p>";
            confirmButton.style.display = "none";   
            showProducts();
            break;

        case "new":
            confirmButton.style.display = "inline-block";
            modalTitle.textContent = "New product";
            modalContent.innerHTML = `
            <input type="text" id="newId" placeholder="Product ID" class="style-form" required>
            <input type="text" id="newName" placeholder="Name of product" class="style-form" required>
            <input type="number" id="newPrice" placeholder="Price of product" class="style-form" required>
            `;
            break;
            
        case "update":
            confirmButton.style.display = "inline-block";
            modalTitle.textContent = "Update product";
            modalContent.innerHTML = `
            <input type="text" id="updateId" placeholder="Product ID to update" class="style-form" required>
            <input type="text" id="updateName" placeholder="Name of product" class="style-form">
            <input type="number" id="updatePrice" placeholder="New price" class="style-form">
            `;
            break;
            
        case "delete":
            confirmButton.style.display = "inline-block";
            modalTitle.textContent = "Delete product";
            modalContent.innerHTML = modalContent.innerHTML = `
                <input type="text" id="deleteId" placeholder="ID del producto a eliminar" class="style-form" required>
                `;
            break;
        } 
    modalCrud.showModal();
}

modalForm.addEventListener('submit', async (e) => {
    e.preventDefault();


    if (choseCrud === 'new') {
    const newProduct = {
      id: document.getElementById('newId').value,
      name: document.getElementById('newName').value,
      price: Number(document.getElementById('newPrice').value)
    };

    try {
      await fetch(BASE_API_URL, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newProduct),
      });
      console.log("Producto agregado:", newProduct);
    } catch (error) {
      console.error("Error al agregar:", error);
    }
  }

  if (choseCrud === 'update') {
    const updateProduct = {
      id: document.getElementById('updateId').value,
      name: document.getElementById('updateName').value,
      price: Number(document.getElementById('updatePrice').value)
    };

    try {
      const response = await fetch(`${BASE_API_URL}/${updateProduct.id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(updateProduct),
      });
      const data = await response.json();
      console.log("Producto actualizado:", data);
    } catch (error) {
      console.error("Error al actualizar:", error);
    }
  }

  if (choseCrud === 'delete') {
    const deleteId = document.getElementById('deleteId').value;

    try {
      const response = await fetch(`${BASE_API_URL}/${deleteId}`, {
        method: 'DELETE'
      });
      const data = await response.json();
      console.log("Producto eliminado:", data);
    } catch (error) {
      console.error("Error al eliminar:", error);
    }
  }

  modalCrud.close();
});

    















// const showProducts = async () => {
//     try{
//         const response = await fetch(`${BASE_API_URL}`);
//         const data = await response.json()
//         console.log(data);
//     }
//     catch (error) {
//         console.error("Error fetching products:", error);
//     }
// }

// Create a new product (POST)
// const newProductFunction = async () => {

// const newProduct = { id: "5", name: "Monitor", price: 233 };

// try {
//     await fetch("http://localhost:3000/products", {
//         method: "POST",
//         headers: { "Content-Type": "application/json" },
//         body: JSON.stringify(newProduct),
//     })
// } catch {
//     console.log("error");
// }
// //   console.log(newProduct)
// };


// const updateProductFunction = async () => {

//     const updateProduct = { "id":"2","name": "Mouse", "price": 140 };

//     try {
//         const response = await fetch(`${BASE_API_URL}/${updateProduct.id}`, {
//         method: 'PUT',
//         headers: {'Content-Type': 'application/json' },
//         body: JSON.stringify(updateProduct),
//         })
//         const data =  await response.json()
//         console.log("Updated product:", data)
//     } catch (error) {
//         rror => console.error("Error gupdating product", error);
//     }
// };  

// const deleteProduct = async () => {
//     const deleteId = 2;
//     try{
//         const response = await fetch(`${BASE_API_URL}/${deleteId}`,{
//         method:'DELETE'
//         })
//         const data = await response.json();
//         console.log("Producto eliminado correctamente", data)
//     }
//     catch (error){
//         console.error('Error al eliminar tarea:', error)
//     }
// }


// ----------------------------------------------------------------------------


// const UpdateProduct = { "name": "Laptop", "price": 1400 };

// fetch('http://localhost:3000/products', {
//     method: 'PUT',
//     headers: {'Content-Type': 'application/json' },
//     body: JSON.stringify(UpdateProduct)
// })
//     .then(response => response.json())
//     .then(data => console.log("Updated product:", data))
//     .catch(error => console.error("Error gupdating product", error));

 // console.log(UpdateProduct)