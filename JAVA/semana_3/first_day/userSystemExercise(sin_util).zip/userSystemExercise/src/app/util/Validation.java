package app.util;

import javax.swing.*;

public class Validation {

    public static String validSearchInput(String search) {
        if (search == null || search.trim().isEmpty()) {
            JOptionPane.showMessageDialog(null, "Search input cannot be empty", "Error!!!", JOptionPane.ERROR_MESSAGE);
            return null;
        }
        return search.trim();
    }

}
