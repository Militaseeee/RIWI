# Financial Transactions Management System

This RESTful API manages customer data, invoices, transactions, and platforms related to financial services like Nequi and Daviplata in Colombia. It structures previously disorganized Excel data into a normalized relational PostgreSQL database, provides bulk data import from CSV, full CRUD functionality, and advanced queries for financial oversight.

---

## 🚀 Database Model and Normalization
The data model was manually normalized through 1NF, 2NF, and 3NF to eliminate redundancy and ensure referential integrity.
- Key entities:
	- **customers:** Unique customers with contact details.
	- **platforms:** Financial platforms (Nequi, Daviplata, etc).
    - **invoices:** Billing information linked to customers.
	- **transactions_status:** Status of transactions (paid, pending, etc.).
	- **transactions:** Payments made by customers, linked to invoices and platforms.

(Relational model diagram attached as MER in the repo)

---

## 📁 Estructura del Proyecto
```
registro_actividades/
├── assets/
│   ├── icons                  
│   └── img                    
├── css/
│   ├── about.css              
│   ├── home.css
│   ├── style.css
│   ├── upload.css
│   └── users.css
├── js/
│   ├── .env   
│   ├── form.js
│   ├── hash.js
│   ├── modal.js
│   ├── navigate.js
│   ├── script.js
│   ├── modal.js
│   ├── services.js
│   ├── upload.js
│   ├── users.js
│   ├── upload_customer.js
│   ├── upload_invoice.js
│   ├── upload_platform.js
│   ├── upload_transaction_status.js
│   ├── upload_transaction.js
│   └── users.js
├── views/
│   ├── about.html                
│   ├── home.html
│   ├── upload_user.html
│   └── users.html
├── MER
├── .env                       
├── .gitignore
├── index.html     
├── install.md  
├── package-lock.json
├── package.json
├── scriptpg.js
└── README.md
```

---

## 🧰 Prerequisites
- Node.js 18+ and npm
- MySQL 8.x running (local or remote)

---

## 🔧 Configuration and Installation

1) Clone the repository
```powershell
git clone https://github.com/Militaseeee/textM4BD.git
cd pd_camila_acosta_gosling;
```

2) Main dependencies and their purpose
```js
import express, { json } from 'express';
import pkg from 'pg';
import cors from 'cors';
import dotenv from 'dotenv';
import multer from 'multer';
import csv from 'csv-parser';
import fs from 'fs';
```

- express → Framework for creating the server and managing HTTP routes.
- pg → Client to connect to PostgreSQL.
- cors → Allows other domains (such as your frontend) to make requests to this server.
- dotenv → Loads environment variables from a .env file.
- multer → Handling of files uploaded by the client (e.g. CSV).
- csv-parser → Reading and converting CSV files to JavaScript objects.
- fs → Node.js module for file management.


3) Create the database in Postgre (adjust port/user if applicable)
   In Supabase, the database is already created by default, but you can create the necessary schema and tables from the SQL section.
   
Example to create the scheme:
```sql
CREATE SCHEMA IF NOT EXISTS pd_camila_acosta_gosling;;
```

4) Create your file `.env`

This project includes `/.env` in `.gitignore`, Therefore, it's not uploaded to GitHub. You must create it locally with the following content. Important: Don't use quotes around values (e.g., DB_NAME=postgres).

```
DB_HOST=aws-0-us-east-1.pooler.supabase.com
DB_USER=postgres.dgzuhlfrgxxdjipbcbcu
DB_PASSWORD= *****
DB_NAME=postgres
DB_PORT=6543
```

Note: If your postgre is listening on the default port, use`DB_PORT=6543`.

5) Start the server (it will automatically create tables if they don't exist)
```powershell
npm start
```

Server available by default in: http://localhost:3000

---

## 🧪 API Endpoints
- CRUD:
    - GET /customers - List all customers
    - GET /customers/:id - Get customer by ID
    - POST /customers - Create a new customer
    - PUT /customers/:id - Update existing customer
    - DELETE /customers/:id - Delete a customer
    - POST /upload/customers-csv - Upload CSV to bulk add customers
-ADVANCED:
    - GET /get_reports/total_paid - Total paid by each customer
    - GET /reports/pending_invoices - Outstanding invoices with customer and associated transaction information
    - GET /reports/transaction/:platformName - Transactions by platform

---

## 🧷 Database Creation Script

- CREATE DATABASE pd_camila_acosta_gosling;

- customers
```sql
CREATE TABLE customers (
  id_customer VARCHAR(20) UNIQUE PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  address VARCHAR(255) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  email VARCHAR(100) UNIQUE
);
```

- platforms
```sql
CREATE TABLE platforms (
  id_platform SERIAL PRIMARY KEY,
  name VARCHAR(50) UNIQUE NOT NULL
);
```

- invoices
```sql
CREATE TABLE invoices (
  id_invoice VARCHAR(20) PRIMARY KEY, 
  period_billing VARCHAR(20) NOT NULL, 
  invoice_total NUMERIC(10,2) NOT NULL,
  id_customer VARCHAR(20) NOT NULL,
  FOREIGN KEY (id_customer) REFERENCES customers(id_customer)
);
```

- transactions_status
```sql
CREATE TABLE transactions_status (
  id_transactions_status SERIAL PRIMARY KEY,
  status VARCHAR(20) NOT NULL
);
```

- transactions
```sql
CREATE TABLE transactions (
  id_transaction VARCHAR(20) PRIMARY KEY,
  transaction_datetime TIMESTAMP NOT NULL,
  transaction_amount NUMERIC(10,2) NOT NULL,
  transaction_type VARCHAR(50), 
  id_invoice VARCHAR(20) NOT NULL, 
  id_platform INT NOT NULL, 
  id_transactions_status INT NOT NULL, 
  FOREIGN KEY (id_invoice) REFERENCES invoices(id_invoice),
  FOREIGN KEY (id_platform) REFERENCES platforms(id_platform),
  FOREIGN KEY (id_transactions_status) REFERENCES transactions_status(id_transactions_status)
);
```

---

## 🧩 Technologies

- **Node.js** + **Express** — Backend server and HTTP route management.
- **PostgreSQL** (`pg`) — Relational database.
- **dotenv** — Handling environment variables.
- **CORS** — Allow requests from other domains.
- **multer** — File upload (CSV).
- **csv-parser** — Reading and parsing CSV files.
- **fs** (Node.js File System) — Server-side file handling.


---

## 🛠️ Scripts npm
- `npm start` — Starts the Express server (creates tables if they do not exist).

---

## ❓ Troubleshooting
- Postgre Connection Error:
	- Check the variables `DB_HOST`, `DB_PORT`, `DB_USER`, `DB_PASS`, `DB_NAME` in you `.env`.
	- Make sure the PostgreSQL service is up and the port is accessible (default 6543).
    - If you are using Supabase or a remote server, check that SSL is enabled (ssl: { rejectUnauthorized: false }).
	- Create the base manually if it doesn't exist.

---

## Developer Info
 - Camila Acosta Velásquez
 - gosling
 - camilitaacosta2001@gmail.com