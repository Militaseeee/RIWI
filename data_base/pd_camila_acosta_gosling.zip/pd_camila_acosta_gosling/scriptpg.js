import express, { json } from 'express';
import pkg from 'pg';
import cors from 'cors';
// import bcrypt from 'bcrypt';
import dotenv from 'dotenv';

import multer from 'multer'; 
import csv from 'csv-parser';
import fs from 'fs';

dotenv.config();

const upload = multer({ dest: 'uploads/' });

const { Pool } = pkg;

const app = express();
app.use(cors());
app.use(json());

// Configuring PostgreSQL with real data
const db = new Pool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT,
    ssl: { rejectUnauthorized: false } // Supabase requiere SSL
});

// Obtener todos los customers
app.get('/customers', async (req, res) => {
    try {
        const { rows } = await db.query('SELECT * FROM customers');
        res.json(rows);
    } catch (err) {
        res.status(500).json(err);
    }
});

// Count customers
app.get('/customers/count', async (req, res) => {
    try {
        const { rows } = await db.query('SELECT COUNT(*) AS count FROM customers');
        res.json(rows[0]);
    } catch (err) {
        res.status(500).json(err);
    }
});

// Aggregate a customer
app.post('/customers', async (req, res) => {
    const { id_customer, name, address, phone, email } = req.body;
    try {
        await db.query(
            `INSERT INTO customers (id_customer, name, address, phone, email) VALUES ($1, $2, $3, $4, $5)`,
            [id_customer, name, address, phone, email]
        );
        res.json({ message: 'Customer aggregate' });
    } catch (err) {
        res.status(500).json(err);
    }
});

// Update a customer
app.put('/customers/:id_customer', async (req, res) => {
    const { id_customer } = req.params;
    const { name, address, phone, email } = req.body;
    try {
        const result = await db.query(
            `UPDATE customers SET name = $1, address = $2, phone = $3, email = $4 WHERE id_customer = $5`,
            [name, address, phone, email, id_customer]
        );
        if (result.rowCount === 0) {
            return res.status(404).json({ message: 'Customer no encontrado' });
        }
        res.json({ message: 'Customer update' });
    } catch (err) {
        res.status(500).json(err);
    }
});

// Removed a customer
app.delete('/customers/:id_customer', async (req, res) => {
    const { id_customer } = req.params;
    try {
        const result = await db.query('DELETE FROM customers WHERE id_customer = $1', [id_customer]);
        if (result.rowCount === 0) {
            return res.status(404).json({ message: 'Customer no encontrado' });
        }
        res.json({ message: 'Customer removed' });
    } catch (err) {
        res.status(500).json(err);
    }
});

// ------------  Advanced Queries (from Postman only) ------------

// Total paid by each customer
app.get('/get_reports/total_paid', async (req, res) => {
  try {
    const query = `
        SELECT c.id_customer, c.name, SUM(t.transaction_amount) AS total_paid FROM customers c
            JOIN invoices i ON c.id_customer = i.id_customer
            JOIN transactions t ON i.id_invoice = t.id_invoice
            GROUP BY c.id_customer, c.name ORDER BY c.name
        ;
    `;
    const { rows } = await db.query(query);
    res.json(rows);
  } catch (err) {
    res.status(500).json(err);
  }
});

// Outstanding invoices with customer and associated transaction information
app.get('/reports/pending_invoices', async (req, res) => {
  try {
    const query = `
        SELECT i.id_invoice, i.period_billing, i.invoice_total, c.name AS customers, SUM(t.transaction_amount) AS total_paid, (i.invoice_total - SUM(t.transaction_amount)) AS outstanding_balance FROM invoices i
            JOIN customers c ON i.id_customer = c.id_customer
            JOIN transactions t ON i.id_invoice = t.id_invoice
            GROUP BY i.id_invoice, i.period_billing, i.invoice_total, c.name
            HAVING (i.invoice_total - SUM(t.transaction_amount)) > 0 ORDER BY c.name
        ;
    `;
    const { rows } = await db.query(query);
    res.json(rows);
  } catch (err) {
    res.status(500).json(err);
  }
});

// Transactions by platform
app.get('/reports/transaction/:platformName', async (req, res) => {
  const { platformName } = req.params;
  try {
    const query = `
        SELECT t.id_transaction, t.transaction_datetime, t.transaction_amount, t.transaction_type, p.name AS platform FROM transactions t
            JOIN platforms p ON t.id_platform = p.id_platform 
            WHERE p.name = $1 ORDER BY t.transaction_datetime DESC
        ;
    `;
    const { rows } = await db.query(query, [platformName]);
    res.json(rows);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// Crear la ruta para subir el CSV y procesarlo
// Configuración multer para almacenar archivos en memoria o disco
app.post('/upload-customers-csv', upload.single('csvFile'), (req, res) => {
  if (!req.file) {
    return res.status(400).json({ message: 'No file uploaded' });
  }

  const filePath = req.file.path;
  const inserts = [];

  fs.createReadStream(filePath)
    .pipe(csv())
    .on('data', (row) => {
      // Expected columns: id_customer, name, address, phone, email
      const id_customer = row.id_customer?.trim();
      const name = row.name?.trim();
      const address = row.address?.trim();
      const phone = row.phone?.trim();
      const email = row.email?.trim();

      if (id_customer && name && address && phone && email) {
        const insertPromise = db.query(
          `INSERT INTO customers (id_customer, name, address, phone, email)
           VALUES ($1, $2, $3, $4, $5)
           ON CONFLICT (id_customer) DO UPDATE 
             SET name = EXCLUDED.name,
                 address = EXCLUDED.address,
                 phone = EXCLUDED.phone,
                 email = EXCLUDED.email`,
          [id_customer, name, address, phone, email]
        );
        inserts.push(insertPromise);
      }
    })
    .on('end', async () => {
      try {
        await Promise.all(inserts);
        fs.unlinkSync(filePath);
        res.json({ message: `Customers inserted successfully (${inserts.length})` });
      } catch (error) {
        console.error('Error inserting customers:', error);
        res.status(500).json({ message: 'Error inserting customers' });
      }
    })
    .on('error', (error) => {
      console.error('Error reading CSV file:', error);
      res.status(500).json({ message: 'Error reading CSV file' });
    });
});






app.listen(3000, () => console.log('Servidor corriendo en http://localhost:3000'));

