CREATE DATABASE pd_camila_acosta_gosling;

CREATE TABLE customers (
  id_customer VARCHAR(20) UNIQUE PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  address VARCHAR(255) NOT NULL,
  phone VARCHAR(40) NOT NULL,
  email VARCHAR(100) UNIQUE
);

CREATE TABLE platforms (
  id_platform SERIAL PRIMARY KEY,
  name VARCHAR(50) UNIQUE NOT NULL
);

CREATE TABLE invoices (
  id_invoice VARCHAR(20) PRIMARY KEY, 
  period_billing VARCHAR(20) NOT NULL, 
  invoice_total NUMERIC(10,2) NOT NULL, -- Monto facturado
  id_customer VARCHAR(20) NOT NULL,
  FOREIGN KEY (id_customer) REFERENCES customers(id_customer)
);

CREATE TABLE transactions_status (
  id_transactions_status SERIAL PRIMARY KEY,
  status VARCHAR(20) NOT NULL
);

CREATE TABLE transactions (
  id_transaction VARCHAR(20) PRIMARY KEY,
  transaction_datetime TIMESTAMP NOT NULL,
  transaction_amount NUMERIC(10,2) NOT NULL, -- Monto pagado
  transaction_type VARCHAR(50), 
  id_invoice VARCHAR(20) NOT NULL, 
  id_platform INT NOT NULL, 
  id_transactions_status INT NOT NULL, 
  FOREIGN KEY (id_invoice) REFERENCES invoices(id_invoice),
  FOREIGN KEY (id_platform) REFERENCES platforms(id_platform),
  FOREIGN KEY (id_transactions_status) REFERENCES transactions_status(id_transactions_status)
);

SELECT c.id_customer, c.name, SUM(t.transaction_amount) AS total_paid FROM customers c
  JOIN invoices i ON c.id_customer = i.id_customer
  JOIN transactions t ON i.id_invoice = t.id_invoice
  GROUP BY c.id_customer, c.name ORDER BY c.name
;

SELECT i.id_invoice, i.period_billing, i.invoice_total, c.name AS customers, SUM(t.transaction_amount) AS total_paid, (i.invoice_total - SUM(t.transaction_amount)) AS outstanding_balance FROM invoices i
  JOIN customers c ON i.id_customer = c.id_customer
  JOIN transactions t ON i.id_invoice = t.id_invoice
  GROUP BY i.id_invoice, i.period_billing, i.invoice_total, c.name
  HAVING (i.invoice_total - SUM(t.transaction_amount)) > 0 ORDER BY c.name
;

SELECT t.id_transaction, t.transaction_datetime, t.transaction_amount, t.transaction_type, p.name AS platform FROM transactions t
  JOIN platforms p ON t.id_platform = p.id_platform WHERE p.name = 'Nequi' ORDER BY t.transaction_datetime DESC
;
