import { getCustomers, createCustomer, updateCustomer, deleteCustomer, countCustomers } from './services.js';

let customers = [];
let isEditing = false;

export function renderCustomers(data) {
  const usersTableBody = document.getElementById('usersTableBody');
  const totalUsersCount = document.getElementById('totalUsersCount');

  usersTableBody.innerHTML = '';

  data.forEach(customer => {
    const row = document.createElement('tr');
    row.innerHTML = `
      <td>${customer.id_customer}</td>
      <td>${customer.name}</td>
      <td>${customer.address}</td>
      <td>${customer.phone}</td>
      <td>${customer.email || ''}</td>
      <td>
          <button class="edit-btn" data-id="${customer.id_customer}">
              <img src="./assets/icons/pencil.png" alt="Edit" class="edit-icon"/>
          </button>
          <button class="delete-btn" data-id="${customer.id_customer}">
              <img src="./assets/icons/trash.png" alt="Delete" class="delete-icon"/>
          </button>
      </td>
    `;
    usersTableBody.appendChild(row);
  });

  if (totalUsersCount) totalUsersCount.textContent = data.length;
}

export async function setupUsersPage() {
  const addUserBtn = document.getElementById('addUserBtn');
  const userModal = document.getElementById('userModal');
  const closeModal = document.getElementById('closeModal');
  const modalTitle = document.getElementById('modalTitle');
  const userForm = document.getElementById('userForm');

  const userIdInput = document.getElementById('userId');
  const userNameInput = document.getElementById('userName');
  const userAddressInput = document.getElementById('userAddress');
  const userPhoneInput = document.getElementById('userPhone');
  const userEmailInput = document.getElementById('userEmail');

  if (!addUserBtn || !userModal || !closeModal || !userForm) {
    console.warn('Elementos DOM no encontrados para usuarios');
    return;
  }

  async function loadUsers() {
    customers = await getCustomers();
    renderCustomers(customers);
    addButtonsListeners();
  }

  function openAddModal() {
    isEditing = false;
    modalTitle.textContent = 'Agregar Cliente';
    userIdInput.value = '';
    userNameInput.value = '';
    userAddressInput.value = '';
    userPhoneInput.value = '';
    userEmailInput.value = '';
    userModal.style.display = 'flex';
  }

  async function openEditModal(id_customer) {
    isEditing = true;
    modalTitle.textContent = 'Editar Cliente';
    const customer = customers.find(c => c.id_customer === id_customer);
    if (!customer) return alert('Cliente no encontrado');

    userIdInput.value = customer.id_customer;
    userNameInput.value = customer.name;
    userAddressInput.value = customer.address;
    userPhoneInput.value = customer.phone;
    userEmailInput.value = customer.email || '';
    userModal.style.display = 'flex';
  }

  async function deleteUserById(id_customer) {
    if (!confirm('¿Seguro que quieres eliminar este cliente?')) return;
    const ok = await deleteCustomer(id_customer);
    if (ok) {
      customers = customers.filter(c => c.id_customer !== id_customer);
      renderCustomers(customers);
      addButtonsListeners();
    } else {
      alert('No se pudo eliminar el cliente');
    }
  }

  function addButtonsListeners() {
    document.querySelectorAll('.edit-btn').forEach(btn => {
      btn.onclick = () => openEditModal(btn.dataset.id);
    });
    document.querySelectorAll('.delete-btn').forEach(btn => {
      btn.onclick = () => deleteUserById(btn.dataset.id);
    });
  }

  // Filtro simple por name o email
  const searchInput = document.getElementById('searchInput');
  searchInput.addEventListener('input', () => {
    const q = searchInput.value.toLowerCase();
    const filtered = customers.filter(c =>
      c.name.toLowerCase().includes(q) ||
      (c.email && c.email.toLowerCase().includes(q))
    );
    renderCustomers(filtered);
    addButtonsListeners();
  });

  userForm.onsubmit = async (e) => {
    e.preventDefault();

    const newUser = {
      id_customer: userIdInput.value.trim(),
      name: userNameInput.value.trim(),
      address: userAddressInput.value.trim(),
      phone: userPhoneInput.value.trim(),
      email: userEmailInput.value.trim() || null,
    };

    try {
      if (isEditing) {
        await updateCustomer(newUser.id_customer, newUser);
      } else {
        await createCustomer(newUser);
      }
      await loadUsers();
      userModal.style.display = 'none';
    } catch (err) {
      console.error('Error guardando cliente:', err);
      alert('Error guardando cliente');
    }
  };

  addUserBtn.onclick = openAddModal;
  closeModal.onclick = () => { userModal.style.display = 'none'; };
  window.onclick = (e) => { if (e.target === userModal) userModal.style.display = 'none'; };

  await loadUsers();
}
