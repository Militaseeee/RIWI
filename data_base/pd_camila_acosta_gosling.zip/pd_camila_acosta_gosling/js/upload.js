import { uploadCustomersCSV } from './services.js';

const csvForm = document.getElementById('csvForm');
const uploadStatus = document.getElementById('uploadStatus');

csvForm.addEventListener('submit', async (e) => {
  e.preventDefault();

  const fileInput = document.getElementById('csvFile');
  const file = fileInput.files[0];

  if (!file) {
    uploadStatus.textContent = 'Por favor selecciona un archivo CSV.';
    return;
  }

  const formData = new FormData();
  formData.append('csvFile', file);

  try {
    const response = await uploadCustomersCSV(formData);

    if (response.message) {
      uploadStatus.textContent = response.message;
    } else {
      uploadStatus.textContent = 'Error: no se recibió respuesta correcta del servidor.';
    }
  } catch (error) {
    uploadStatus.textContent = 'Error de red o servidor.';
    console.error(error);
  }
});
