// URL base de la API
const BASE_URL = 'http://localhost:3000';

// ===================== CUSTOMERS =====================

// Obtenemos todos los customers
export async function getCustomers() {
    const res = await fetch(`${BASE_URL}/customers`);
    return res.json();
}

// Obtenemos el conteo total de customers
export async function countCustomers() {
    const res = await fetch(`${BASE_URL}/customers/count`);
    return res.json();
}

// Creamos un nuevo customer
export async function createCustomer(customer) {
    const res = await fetch(`${BASE_URL}/customers`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(customer),
    });
    return res.json();
}

// Actualizamos un customer existente por su id_customer
export async function updateCustomer(id_customer, customer) {
    const res = await fetch(`${BASE_URL}/customers/${id_customer}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(customer),
    });
    return res.json();
}

// Eliminamos un customer por su id_customer
export async function deleteCustomer(id_customer) {
    const res = await fetch(`${BASE_URL}/customers/${id_customer}`, {
        method: 'DELETE',
    });
    return res.ok;
}


// ===================== REPORTS AVANZADOS =====================

// 1. Total pagado por cada cliente
export async function getTotalPaidByCustomer() {
    const res = await fetch(`${BASE_URL}/get_reports/total_paid`);
    return res.json();
}

// 2. Facturas pendientes con info cliente y transacción asociada
export async function getPendingInvoices() {
    const res = await fetch(`${BASE_URL}/reports/pending_invoices`);
    return res.json();
}

// 3. Listado de transacciones por plataforma
export async function getTransactionsByPlatform(platformName) {
    const res = await fetch(`${BASE_URL}/reports/transaction/${platformName}`);
    return res.json();
}


// ===================== MASSIVE IMPORT =====================

// Subimos un archivo CSV con customers para importación masiva
export async function uploadCustomersCSV(formData) {
    const res = await fetch(`${BASE_URL}/upload-customers-csv`, {
        method: 'POST',
        body: formData
    });
    return res.json();
}