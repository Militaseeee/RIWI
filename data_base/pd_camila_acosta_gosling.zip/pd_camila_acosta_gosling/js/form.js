import { closeModal } from "./modal";
import { navigate } from "./navigate";
// import { counterId } from "./script";

// FORM LOGIC
// Main logic of the form
export function setListeners() {
    // We get the necessary DOM elements
    const addBtn = document.getElementById("addEventsBtn");
    const closeBtn = document.querySelector(".close-btn");
    const modal = document.getElementById("bookModal");
    const form = document.getElementById("eventForm");

     // If the add activity button exists, we add an event to navigate to the form
    if (addBtn) {
        addBtn.addEventListener("click", () => navigate("/add_activity"));
    }

    if (closeBtn) {
        closeBtn.addEventListener("click", closeModal);
    }

    if (modal) {
        window.addEventListener("click", (e) => {
            if (e.target === modal) closeModal();
        });
    }

    // Listener to submit the form (create or edit book)
    if (form) {
        form.addEventListener("submit", async (e) => {
            e.preventDefault();

            const id_registro = document.getElementById("categoryId").value;

            const userData = JSON.parse(localStorage.getItem("UserData"));
            if (!userData) {
                alert("Usuario no autenticado");
                return;
            }

            // If the book already exists (edit mode), we recover its loan status
            if (id_registro) {
                const events = await getActividades();
                const existingActivity = events.find((b) => b.id_registro == id_registro);
                // borrowedBy = existingBook?.borrowedBy || []; // We maintain the original state
            }
            
            // We create the book object with the form data
            const data = {
                id_usuario: userData.id_usuario,
                nombre_actividad: document.getElementById("nombre_actividad").value,
                fecha: document.getElementById("date").value,
                duracion_min: parseInt(document.getElementById("duration").value),
                descripcion: document.getElementById("description").value
            };

            
            if (id_registro) {
                // Modo EDICIÓN
                await updateActividad(id_registro, data);
                alert("Actividad actualizada correctamente");
            } else {
                // Modo CREACIÓN
                await createActividades(data);
                alert("Actividad creada correctamente");
            }

            const eventos = await getActividadesPorUsuario(userData.id_usuario);
            renderActividades(eventos);
            closeModal();

        });
    }
}

