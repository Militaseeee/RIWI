import 'dotenv/config';
import fs from 'fs';
import csv from 'csv-parser';
import pkg from 'pg';

const { Pool } = pkg;

const connection = new Pool({
    host: process.env.DB_HOST,
    user: process.env.DB_USER,
    password: process.env.DB_PASSWORD,
    database: process.env.DB_NAME,
    port: process.env.DB_PORT,
    ssl: { rejectUnauthorized: false } 
});

const inserts = []; // Aquí acumularemos las promesas

fs.createReadStream('../uploads/invoices.csv')
  .pipe(csv())
  .on('data', (row) => {
    const query = connection.query(
      'INSERT INTO public.invoices (id_invoice, period_billing, invoice_total, id_customer) VALUES ($1, $2, $3, $4)',
      [row.id_invoice, row.period_billing, row.invoice_total, row.id_customer]
    );
    inserts.push(query); // Guardamos la promesa
  })
  .on('end', async () => {
    try {
      await Promise.all(inserts); // Esperamos a que todos los inserts terminen
      console.log(`Se insertaron ${inserts.length} registros correctamente.`);
    } catch (err) {
      console.error('Error durante la inserción:', err);
    } finally {
      await connection.end(); // Cerramos la conexión cuando todo termine
      console.log('Conexión cerrada.');
    }
  });