CREATE DATABASE IF NOT EXISTS empleadosdb;

USE empleadosdb;

CREATE TABLE empleados (
	id_empleado INT AUTO_INCREMENT PRIMARY KEY,
	nombre VARCHAR(100),
	edad INT,
	salario DECIMAL(12,2),
	departamento VARCHAR(50)
);

INSERT INTO empleados (nombre, edad, salario, departamento) VALUES
	('Ana Torres', 30, 4500000, 'TI'),
	('Luis Gómez', 25, 3000000, 'Ventas'),
	('Carlos Ruiz', 40, 5200000, 'TI'),
	('Marta López', 35, 3500000, 'Ventas'),
	('Julián Sánchez', 29, 2800000, 'Marketing'),
	('Paula Pérez', 45, 6000000, 'Gerencia'),
	('Camila Díaz', 26, 3000000, NULL),
	('Juan Rodríguez', 38, 4100000, 'TI'),
	('Laura Jiménez', 32, 3900000, 'Marketing'),
	('Pedro Castillo', 28, 3100000, 'Ventas'),
	('Lucía Ríos', 31, 4800000, 'TI'),
	('Esteban Vargas', 42, 2950000, 'Recursos Humanos'),
	('Natalia Giraldo', 27, 3150000, 'TI'),
	('Sofía Herrera', 36, 4100000, 'Gerencia'),
	('Samuel Patiño', 33, 2700000, 'Marketing'),
	('Daniela Cardona', 30, 3300000, 'Ventas')
;

SELECT nombre, salario FROM empleados;

SELECT nombre, salario FROM empleados WHERE salario > 3000000

SELECT * FROM empleados ORDER BY edad ASC 

SELECT * FROM empleados WHERE departamento IN ('ventas', 'TI')

