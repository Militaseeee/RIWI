// npm init -y
// npm install bcrypt
// node hash.js

const bcrypt = require('bcrypt');
const password = 'admin123*';

bcrypt.hash(password, 10, (err, hash) => {
    if (err) throw err;
    console.log("Hash generado:", hash);
});