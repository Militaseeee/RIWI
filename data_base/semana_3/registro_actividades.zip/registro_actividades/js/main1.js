// Configuration
const API_BASE_URL = 'http://localhost:3000';

// Global state
let currentUser = null;
let categorias = [];
let actividades = [];
let usuarios = [];

// DOM Elements
const loginScreen = document.getElementById('login-screen');
const registerScreen = document.getElementById('register-screen');
const dashboardScreen = document.getElementById('dashboard-screen');

// Initialize app
document.addEventListener('DOMContentLoaded', function() {
    initializeApp();
    setupEventListeners();
    setCurrentDate();
});

function initializeApp() {
    // Check if user is logged in (simple check - in production use JWT tokens)
    const savedUser = localStorage.getItem('currentUser');
    if (savedUser) {
        currentUser = JSON.parse(savedUser);
        showDashboard();
    } else {
        showLogin();
    }
}

function setupEventListeners() {
    // Login form
    document.getElementById('login-form').addEventListener('submit', handleLogin);
    
    // Register form
    document.getElementById('register-form').addEventListener('submit', handleRegister);
    
    // Activity form
    document.getElementById('activity-form').addEventListener('submit', handleActivitySubmit);
    
    // Category change listener
    document.getElementById('categoria').addEventListener('change', loadActivitiesByCategory);
}

function setCurrentDate() {
    const today = new Date().toISOString().split('T')[0];
    document.getElementById('fecha').value = today;
}

// Screen Navigation
function showScreen(screenId) {
    document.querySelectorAll('.screen').forEach(screen => {
        screen.classList.remove('active');
    });
    document.getElementById(screenId).classList.add('active');
}

function showLogin() {
    showScreen('login-screen');
}

function showRegister() {
    showScreen('register-screen');
}

function showDashboard() {
    showScreen('dashboard-screen');
    if (currentUser) {
        document.getElementById('user-name').textContent = currentUser.nombre;
        loadDashboardData();
    }
}

// Tab Navigation
function showTab(tabName) {
    // Remove active class from all tabs and contents
    document.querySelectorAll('.tab-btn').forEach(btn => btn.classList.remove('active'));
    document.querySelectorAll('.tab-content').forEach(content => content.classList.remove('active'));
    
    // Add active class to selected tab and content
    event.target.classList.add('active');
    document.getElementById(tabName + '-tab').classList.add('active');
    
    // Load specific data for the tab
    if (tabName === 'history') {
        loadActivitiesHistory();
    } else if (tabName === 'users') {
        loadUsers();
    } else if (tabName === 'activities') {
        loadFormData();
    }
}

// Authentication
async function handleLogin(e) {
    e.preventDefault();
    
    const correo = document.getElementById('login-email').value;
    const contrasena = document.getElementById('login-password').value;
    
    try {
        const response = await fetch(`${API_BASE_URL}/login`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ correo, contrasena })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            // Get user data
            const userResponse = await fetch(`${API_BASE_URL}/usuarios`);
            const users = await userResponse.json();
            const user = users.find(u => u.correo === correo);
            
            if (user) {
                currentUser = user;
                localStorage.setItem('currentUser', JSON.stringify(user));
                showToast('Login exitoso', 'success');
                showDashboard();
            }
        } else {
            showToast(data.mensaje || 'Error en el login', 'error');
        }
    } catch (error) {
        showToast('Error de conexión', 'error');
        console.error('Error:', error);
    }
}

async function handleRegister(e) {
    e.preventDefault();
    
    const nombre = document.getElementById('register-name').value;
    const correo = document.getElementById('register-email').value;
    const password = document.getElementById('register-password').value;
    
    try {
        const response = await fetch(`${API_BASE_URL}/registro`, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({ nombre, correo, password })
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showToast('Cuenta creada exitosamente', 'success');
            showLogin();
            // Clear form
            document.getElementById('register-form').reset();
        } else {
            showToast(data.message || 'Error al crear cuenta', 'error');
        }
    } catch (error) {
        showToast('Error de conexión', 'error');
        console.error('Error:', error);
    }
}

function logout() {
    currentUser = null;
    localStorage.removeItem('currentUser');
    showLogin();
    showToast('Sesión cerrada', 'success');
}

// Data Loading
async function loadDashboardData() {
    await Promise.all([
        loadFormData(),
        loadUserCount()
    ]);
}

async function loadFormData() {
    try {
        // For now, we'll use mock data since the backend doesn't have these endpoints
        // In a real app, you'd fetch from your API
        categorias = [
            { id_categoria: 1, nombre: 'Ejercicio' },
            { id_categoria: 2, nombre: 'Estudio' },
            { id_categoria: 3, nombre: 'Trabajo' },
            { id_categoria: 4, nombre: 'Hobbies' }
        ];
        
        actividades = [
            { id_actividad: 1, nombre: 'Correr', id_categoria: 1 },
            { id_actividad: 2, nombre: 'Gimnasio', id_categoria: 1 },
            { id_actividad: 3, nombre: 'Leer', id_categoria: 2 },
            { id_actividad: 4, nombre: 'Programar', id_categoria: 3 },
            { id_actividad: 5, nombre: 'Dibujar', id_categoria: 4 }
        ];
        
        populateCategories();
    } catch (error) {
        showToast('Error cargando datos del formulario', 'error');
        console.error('Error:', error);
    }
}

function populateCategories() {
    const categoriaSelect = document.getElementById('categoria');
    categoriaSelect.innerHTML = '<option value="">Seleccionar categoría</option>';
    
    categorias.forEach(categoria => {
        const option = document.createElement('option');
        option.value = categoria.id_categoria;
        option.textContent = categoria.nombre;
        categoriaSelect.appendChild(option);
    });
}

function loadActivitiesByCategory() {
    const categoriaId = parseInt(document.getElementById('categoria').value);
    const actividadSelect = document.getElementById('actividad');
    
    actividadSelect.innerHTML = '<option value="">Seleccionar actividad</option>';
    
    if (categoriaId) {
        const filteredActividades = actividades.filter(act => act.id_categoria === categoriaId);
        
        filteredActividades.forEach(actividad => {
            const option = document.createElement('option');
            option.value = actividad.id_actividad;
            option.textContent = actividad.nombre;
            actividadSelect.appendChild(option);
        });
    }
}

async function loadUserCount() {
    try {
        const response = await fetch(`${API_BASE_URL}/usuarios/count`);
        const data = await response.json();
        document.getElementById('user-count').textContent = data.num_usuarios || 0;
    } catch (error) {
        console.error('Error loading user count:', error);
    }
}

async function loadUsers() {
    try {
        const response = await fetch(`${API_BASE_URL}/usuarios`);
        usuarios = await response.json();
        displayUsers();
    } catch (error) {
        showToast('Error cargando usuarios', 'error');
        console.error('Error:', error);
    }
}

function displayUsers() {
    const usersList = document.getElementById('users-list');
    
    if (usuarios.length === 0) {
        usersList.innerHTML = '<p class="text-center">No hay usuarios registrados</p>';
        return;
    }
    
    usersList.innerHTML = usuarios.map(user => `
        <div class="user-item">
            <div class="user-info">
                <h4>${user.nombre}</h4>
                <p>${user.correo}</p>
            </div>
            <div class="user-actions">
                <button class="btn btn-small btn-danger" onclick="deleteUser(${user.id_usuario})">
                    Eliminar
                </button>
            </div>
        </div>
    `).join('');
}

async function loadActivitiesHistory() {
    // Mock data for activities history
    const mockActivities = [
        {
            id_registro: 1,
            actividad: { nombre: 'Correr' },
            categoria: { nombre: 'Ejercicio' },
            duracion_min: 30,
            descripcion: 'Corrí en el parque',
            fecha: '2024-01-15'
        },
        {
            id_registro: 2,
            actividad: { nombre: 'Leer' },
            categoria: { nombre: 'Estudio' },
            duracion_min: 60,
            descripcion: 'Leí un libro de programación',
            fecha: '2024-01-14'
        }
    ];
    
    displayActivitiesHistory(mockActivities);
}

function displayActivitiesHistory(activities) {
    const activitiesList = document.getElementById('activities-list');
    
    if (activities.length === 0) {
        activitiesList.innerHTML = '<p class="text-center">No hay actividades registradas</p>';
        return;
    }
    
    activitiesList.innerHTML = activities.map(activity => `
        <div class="activity-item">
            <div class="activity-info">
                <h4>${activity.actividad.nombre}</h4>
                <p><strong>Categoría:</strong> ${activity.categoria?.nombre || 'Sin categoría'}</p>
                ${activity.descripcion ? `<p><strong>Descripción:</strong> ${activity.descripcion}</p>` : ''}
            </div>
            <div class="activity-meta">
                <p><strong>Fecha:</strong> ${formatDate(activity.fecha)}</p>
                ${activity.duracion_min ? `<p><strong>Duración:</strong> ${activity.duracion_min} min</p>` : ''}
            </div>
        </div>
    `).join('');
}

// Form Submissions
async function handleActivitySubmit(e) {
    e.preventDefault();
    
    const formData = {
        id_usuario: currentUser.id_usuario,
        id_actividad: parseInt(document.getElementById('actividad').value),
        duracion_min: document.getElementById('duracion').value ? parseInt(document.getElementById('duracion').value) : null,
        descripcion: document.getElementById('descripcion').value || null,
        fecha: document.getElementById('fecha').value
    };
    
    if (!formData.id_actividad || !formData.fecha) {
        showToast('Por favor completa los campos requeridos', 'error');
        return;
    }
    
    try {
        // Since the backend doesn't have this endpoint, we'll simulate success
        // In a real app: const response = await fetch(`${API_BASE_URL}/registros`, { method: 'POST', ... });
        
        showToast('Actividad registrada exitosamente', 'success');
        document.getElementById('activity-form').reset();
        setCurrentDate();
        
        // Reset selects
        document.getElementById('categoria').value = '';
        document.getElementById('actividad').innerHTML = '<option value="">Seleccionar actividad</option>';
        
    } catch (error) {
        showToast('Error al registrar actividad', 'error');
        console.error('Error:', error);
    }
}

// User Management
async function deleteUser(userId) {
    if (!confirm('¿Estás seguro de que quieres eliminar este usuario?')) {
        return;
    }
    
    try {
        const response = await fetch(`${API_BASE_URL}/usuarios/${userId}`, {
            method: 'DELETE'
        });
        
        const data = await response.json();
        
        if (response.ok) {
            showToast('Usuario eliminado exitosamente', 'success');
            loadUsers();
            loadUserCount();
        } else {
            showToast(data.message || 'Error al eliminar usuario', 'error');
        }
    } catch (error) {
        showToast('Error de conexión', 'error');
        console.error('Error:', error);
    }
}

// Utility Functions
function formatDate(dateString) {
    const date = new Date(dateString);
    return date.toLocaleDateString('es-ES');
}

function showToast(message, type = 'success') {
    const toastContainer = document.getElementById('toast-container');
    
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <p>${message}</p>
    `;
    
    toastContainer.appendChild(toast);
    
    // Remove toast after 3 seconds
    setTimeout(() => {
        toast.remove();
    }, 3000);
}