import { navigate } from "./navigate";
import { setListeners } from './form';

// INIT APP
export async function initApp() {
  console.log("🚀 initApp executed from script.js");

  setListeners(); // Configuramos los listeners de formularios u otros elementos

  const logoutBtn = document.getElementById('logout');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      navigate('/home');
    });
  }

  // Carga inicial (puede ser /home o la ruta actual)
  await navigate(location.pathname === "/" ? "/home" : location.pathname);
}
initApp();

// SPA Navigation
document.body.addEventListener("click", (e) => {
  if (e.target.closest("[data-link]")) {
    e.preventDefault();
    const path = e.target.closest("[data-link]").getAttribute("href");
    navigate(path);
  }

  const logoutBtn = document.getElementById('logout');
  if (logoutBtn) {
    logoutBtn.addEventListener('click', () => {
      navigate('/home');
    });
  }
});

window.addEventListener("popstate", () => {
  navigate(location.pathname);
});
