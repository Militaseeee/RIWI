import { getCustomers, createCustomer, updateCustomer, deleteCustomer, countCustomers, uploadCustomersCSV } from './services.js';

import { setupUsersPage } from './users.js'; 
// import { uploadUsuariosCSV } from './services.js';


const routes = {
  "/": "./index.html",
  "/home": './views/home.html',
  "/upload_user": '/views/upload_user.html',
  "/users": '/views/users.html',
  "/add_user": '/views/add_user.html',
  "/about": '/views/about.html',
};

// Main function to load views
export async function navigate(pathname) {

  const sidebar = document.getElementById("sidebar");
  if (sidebar) {
    // Siempre mostrar sidebar, no ocultar en /home
    sidebar.style.display = "flex";
  }

  const route = routes[pathname];
  if (!route) return console.error("Invalid route");

  // We load the corresponding HTML view
  const html = await fetch(route).then((res) => res.text());
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  
  // We replace the content dynamically
  const newContent = doc.getElementById("content");
  const content = document.getElementById("content");

  content.innerHTML = newContent ? newContent.innerHTML : doc.body.innerHTML;
  history.pushState({}, "", pathname);

  // We changed avatar and items according to the role in overviews
  if (pathname === "/home" ||  pathname === "/about" || pathname === "/upload_user" || pathname === "/users") {
        
  }

    if (pathname === "/users") {
    const sidebar = document.getElementById("sidebar");
    if (sidebar) sidebar.style.display = "flex";

    // Configurar la página de usuarios (carga datos, eventos, etc)
    await setupUsersPage();
  }

  if (pathname === "/add_user") {
    // Botón para volver a Users
    const goBackBtn = document.getElementById("goBackBtn");
    if (goBackBtn) {
        goBackBtn.addEventListener("click", () => {
            navigate("/users");
        });
    }

    // Manejar envío de formulario
    const userForm = document.getElementById('userForm');
    if (userForm) {
        userForm.addEventListener('submit', async (e) => {
            e.preventDefault();

            const newUser = {
                nombre: document.getElementById('userName').value.trim(),
                correo: document.getElementById('userEmail').value.trim(),
                rol: document.getElementById('userRole').value
            };

            try {
                await createUsuario(newUser);
                alert('Usuario agregado con éxito');
                navigate('/users'); // SPA, no recarga
            } catch (err) {
                console.error('Error creando usuario:', err);
                alert('No se pudo agregar el usuario');
            }
        });
    }
  }


    if (pathname === "/upload_user") {
        // Make sure the DOM already contains the form
        const csvForm = document.getElementById('csvForm');
        if (csvForm) {
            // Listen for the form submission event
            csvForm.addEventListener('submit', async (e) => {
                e.preventDefault(); // Prevent the default form submission to handle it with JavaScript
                
                // Get the CSV file selected by the user
                const fileInput = document.getElementById('csvFile');
                const file = fileInput.files[0];
                
                // Validate that a file has actually been selected
                if (!file) {
                  const uploadStatus = document.getElementById('uploadStatus');
                  if (uploadStatus) uploadStatus.textContent = 'Please select a CSV file.';
                  return; // Stop execution if there is no file
                }
              
                // Prepare the data to send it to the server
                const formData = new FormData();
                formData.append('csvFile', file);
              
                try {
                  // Send the file to the backend using the uploadCustomersCSV function
                  const data = await uploadCustomersCSV(formData);

                  // Show the message returned by the server
                  const uploadStatus = document.getElementById('uploadStatus');
                  if (data.message) {
                    uploadStatus.textContent = data.message;
                  } else {
                    uploadStatus.textContent = 'Error: no valid response received';
                  }
                } catch (err) {
                  // Show an error message if there was a network or server problem
                  const uploadStatus = document.getElementById('uploadStatus');
                  uploadStatus.textContent = 'Network or server error.';
                  console.error(err);
                }
            });
        }
    }

    const logoutBtn = document.getElementById('logout');
    if (logoutBtn) {
        logoutBtn.addEventListener('click', () => {
            navigate('/home');
        });
    }


}