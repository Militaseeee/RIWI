import { initApp, isAuth, setupLoginForm } from "./script";
import { registrarUsuario, createActividades, updateActividad } from "./services";
import { setupSearch, renderActividades } from './activitiesTable';
import { setDateInputValidation, llenarSelectActividades, formatDateToSave } from './form';


const routes = {
  "/": "./index.html",
  "/home": './views/home.html',
  "/login": './views/login.html',
  "/register": './views/register.html',
  "/activities": './views/activities.html',
  "/add_activity": '/views/add_activity.html',
};

// Main function to load views
export async function navigate(pathname) {

  // Block to replace the values of HTML elements with their respective user role
  const userData = await JSON.parse(localStorage.getItem("UserData"));
  let valRol = false;
  if (userData) {
    document.getElementById("nameUser").textContent = userData.name;
    document.getElementById("role").textContent = userData.role;
  }

    // If the user is not authenticated, we redirect to login
    if( !isAuth()&& location.pathname === '/register'){
    pathname = '/register'
    } else if(!isAuth) {
        pathname='/login'
    }
    
    // if (!isAuth() && pathname !== '/login' && pathname !== '/register') {
    //     pathname = '/login';
    // }

  const route = routes[pathname];
  if (!route) return console.error("Invalid route");

  // We load the corresponding HTML view
  const html = await fetch(route).then((res) => res.text());
  const parser = new DOMParser();
  const doc = parser.parseFromString(html, "text/html");
  
  // We replace the content dynamically
  const newContent = doc.getElementById("content");
  const content = document.getElementById("content");

  content.innerHTML = newContent ? newContent.innerHTML : doc.body.innerHTML;
  history.pushState({}, "", pathname);

  // We changed avatar and items according to the role in overviews
  if (pathname === "/home" || pathname === "/activities" || pathname === "/add_activity" || pathname === "/about" || pathname === "/my_books" || pathname === "/available_events") {
    
    const changeImg = document.getElementById('changePicture');

    if (userData.role === "user") {
      changeImg.src = './assets/img/user.png';
    } else if (userData.role === "admin") {
      changeImg.src = './assets/img/admin2.png';
    }

    // const userBooksLink = document.getElementById("userBooksLink");
    // userBooksLink.style.display = userData.role === "User" ? "flex" : "none";
        
  }

     // Special settings for login view
    if (pathname === "/login") {
        const main = document.getElementById('content');
        const sidebar = document.getElementById("sidebar");
        sidebar.style.display = "none";
        main.classList.add("login-centered");
        setupLoginForm();
    } else {
        const main = document.getElementById('content');
        const sidebar = document.getElementById("sidebar");
        sidebar.style.display = "flex";
        main.classList.remove("login-centered");
    }

  // We handle the highlighting of the active option of the sidebar
  // Update the .active class in the sidebar
  document.querySelectorAll(".sidebar nav ul li").forEach((li) => {
    const a = li.querySelector("a");
    if (a && a.getAttribute("href") === pathname) {
      li.classList.add("active");
    } else {
      li.classList.remove("active");
    }
  });


  if (pathname === "/register") {
    const main = document.getElementById('content');
    const sidebar = document.getElementById("sidebar");
    sidebar.style.display = "none";
    main.classList.add("login-centered");
  }

  // register.js
    if (pathname === "/register") {

    const roles = document.getElementById("registerForm");

    const psw = document.getElementById("password");
    const pswCon = document.getElementById("confirm_password");
    
    roles.addEventListener("submit", async (e) => {
      e.preventDefault();

      const newUser  = {
        "nombre": roles.name.value,
        "correo": roles.email.value,
        "rol": "user",
        "password": roles.password.value,
        // "confirm_password": roles.confirm_password.value,
      };

    //   if (newUser.password !== newUser.confirm_password) {
    //     alert("The password and password confirmation must be the same.");
    //     return;
    //   }
      
      alert("User created successfully! You will be redirected to the login page.");
      await registrarUsuario(newUser);
      navigate("/login");
    });
  }

  // Special logic for book viewing
  if (pathname === "/activities") {

    // renderActividades();

    const changeImg = document.getElementById('changePicture');

    if (userData.role === "user") {
      changeImg.src = './assets/img/user.png';
    } else if (userData.role === "admin") {
      changeImg.src = './assets/img/admin2.png';
    }

    await initApp()

    setupSearch();

    switch(userData.role){
      case 'Admin':

        const deleteWrapper = document.getElementById('addEventsBtn')
        deleteWrapper.style.display = 'block'

        // Hide the "Borrow" buttons for the admin
        document.querySelectorAll(".borrow-btn").forEach((btn) => {
          btn.style.display = "none";
        });

        break;
      case 'User':

        hideActionColumn();

        // Hide edit and delete buttons
        const editButton = document.querySelectorAll('.edit-btn').forEach(btnEdit => {
          btnEdit.style.display = 'none';
        })
        const deleteButton = document.querySelectorAll('.delete-btn').forEach(deleteBtn => {
          deleteBtn.style.display = 'none';
        })

        const addBtn = document.getElementById('addEventsBtn');
        if (addBtn) addBtn.style.display = 'none';

        const actionDelete = document.getElementById('actionDeleteEvent');
        if (actionDelete) actionDelete.style.display = 'none';
  
        break;
        
      default:
        break
    }
  }

  // Logic for the add book view
  if (pathname === "/add_activity") {
    setDateInputValidation(); 

    llenarSelectActividades();

    // Aquí pon esta línea:
    const userData = JSON.parse(localStorage.getItem("UserData"));
    if(userData && userData.id_usuario){
      const inputUser = document.getElementById("id_usuario");
      if(inputUser) inputUser.value = userData.id_usuario;
    }

    const form = document.getElementById("addEventForm");
    
    form.addEventListener("submit", async (e) => {
      e.preventDefault();

      // We created a new book
      const newActivity  = {
        id_usuario: form.id_usuario.value,
        nombre_actividad: form.nombre_actividad.value,
        fecha: formatDateToSave(form.fecha.value),
        duracion_min: form.duracion_min.value,
        descripcion: form.descripcion.value
        // "borrowedBy": []
      };
      
      await createActividades(newActivity);
      navigate("/activities");
    });

    const goBackBtn = document.getElementById("goBackBtn");
    if (goBackBtn) {
      goBackBtn.addEventListener("click", () => {
        navigate("/activities");
      });
    }
  }


}