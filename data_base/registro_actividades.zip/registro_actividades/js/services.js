const BASE_URL = 'http://localhost:3000';

// Usuarios
export async function getUsuarios() {
    const res = await fetch(`${BASE_URL}/usuarios`);
    return res.json();
}

export async function countUsuarios() {
    const res = await fetch(`${BASE_URL}/usuarios/count`);
    return res.json();
}

export async function createUsuario(usuario) {
    const res = await fetch(`${BASE_URL}/usuarios`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(usuario),
    });
    return res.json();
}

export async function updateUsuario(id, usuario) {
    const res = await fetch(`${BASE_URL}/usuarios/${id}`, {
        method: 'PUT',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(usuario),
    });
    return res.json();
}

export async function deleteUsuario(id) {
    const res = await fetch(`${BASE_URL}/usuarios/${id}`, {
        method: 'DELETE' });
    return res.ok;
}

// Registro
export async function registrarUsuario(data) {
    const res = await fetch(`${BASE_URL}/registro`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
    });
    return res.json();
}

// Login
export async function loginUsuario(data) {
    const res = await fetch(`${BASE_URL}/login`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data),
    });
    return res.json();
}








// getActividades() -> para vista para admin

export async function getActividades() {
    const res = await fetch(`${BASE_URL}/actividades`);
    return res.json();
}


export async function getActividadesPorUsuario(id_usuario) {
    const res = await fetch(`${BASE_URL}/actividades/usuario/${id_usuario}`);
    return res.json();
}



export async function getActividadesDisponibles() {
    const res = await fetch(`${BASE_URL}/actividades-disponibles`);
    return res.json();
}



export async function createActividades(data) {
    const res = await fetch(`${BASE_URL}/registro-actividad`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
    });
    return res.json();
}


export async function updateActividad(id_registro, data) {
    const res = await fetch(`${BASE_URL}/registro-actividad/${id_registro}`, {
        method: "PUT",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data),
    });
    return res.json();
}


export async function deleteActividad(id_registro) {
    const res = await fetch(`${BASE_URL}/eliminar-actividad/${id_registro}`, {
        method: 'DELETE',
    });
    return res.ok;
}
